import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import {
  resolveLocation,
  searchGrants,
  type Category,
  type EntityType,
  type Grant,
  type ResolvedLocation,
  type Tier,
  CATEGORY_IDS,
} from "@/lib/grants.functions";
import { useFavorites, useSavedSearches } from "@/lib/saved";
import { GrantEligibility, ProfileFields } from "@/components/grant-eligibility";
import type { ClientProfile, FitAssessment } from "@/lib/eligibility";
import { grantKey } from "@/lib/saved";

export const Route = createFileRoute("/")({
  validateSearch: (q: Record<string, unknown>): { s?: string } => (typeof q["s"] === "string" ? { s: q["s"] } : {}),
  head: () => ({
    meta: [
      { title: "Grantscope — Foundation grant search for nonprofits, schools & cities" },
      { name: "description", content: "Enter your organization and find local, state/regional and national foundation grants with amounts, deadlines and application complexity." },
      { property: "og:title", content: "Grantscope — Foundation grant search" },
      { property: "og:description", content: "Local, regional and national foundation grants for nonprofits, schools and municipalities." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const TIERS: { id: Tier; label: string; ring: string }[] = [
  { id: "local", label: "Local", ring: "01" },
  { id: "regional", label: "State & Regional", ring: "02" },
  { id: "national", label: "National", ring: "03" },
];

type TierState = { status: "idle" | "loading" | "done" | "error"; grants: Grant[]; error?: string };
const emptyTiers = (): Record<Tier, TierState> => ({
  local: { status: "idle", grants: [] },
  regional: { status: "idle", grants: [] },
  national: { status: "idle", grants: [] },
});

const CATEGORY_LABEL: Record<Category, string> = {
  education: "Education",
  infrastructure: "Infrastructure",
  "community-programs": "Community programs",
  health: "Health & human services",
  "arts-culture": "Arts & culture",
  environment: "Environment",
  "economic-development": "Economic development",
  "public-safety": "Public safety",
  other: "Other",
};

const catOf = (g: Grant): Category => (CATEGORY_IDS.includes(g.category) ? g.category : "other");

const money = (n: number | null) =>
  n == null ? "—" : n >= 1_000_000 ? `$${(n / 1_000_000).toFixed(n % 1_000_000 ? 1 : 0)}M` : n >= 1000 ? `$${Math.round(n / 1000)}K` : `$${n}`;

const range = (g: Grant) =>
  g.minAmount == null && g.maxAmount == null
    ? "Varies"
    : g.minAmount == null
      ? `Up to ${money(g.maxAmount)}`
      : g.maxAmount == null
        ? `From ${money(g.minAmount)}`
        : `${money(g.minAmount)} – ${money(g.maxAmount)}`;

function Index() {
  const resolveFn = useServerFn(resolveLocation);
  const searchFn = useServerFn(searchGrants);

  const [name, setName] = useState("");
  const [type, setType] = useState<EntityType>("nonprofit");
  const [focus, setFocus] = useState("");
  const [profile, setProfile] = useState<ClientProfile>({ mission: "", goals: "" });
  const [loc, setLoc] = useState<ResolvedLocation | null>(null);
  const [locating, setLocating] = useState(false);
  const [locError, setLocError] = useState("");
  const [tiers, setTiers] = useState(emptyTiers);
  const [active, setActive] = useState<Tier>("local");
  const [selectedCats, setSelectedCats] = useState<Category[]>([]);
  const [justSaved, setJustSaved] = useState(false);
  const favorites = useFavorites();
  const saved = useSavedSearches();
  const { s: savedId } = Route.useSearch();

  async function findLocation(e: React.FormEvent) {
    e.preventDefault();
    setLocError("");
    setLocating(true);
    setTiers(emptyTiers());
    setSelectedCats([]);
    setJustSaved(false);
    try {
      setLoc(await resolveFn({ data: { name, type } }));
    } catch (err) {
      setLocError(err instanceof Error ? err.message : "Could not find location.");
    } finally {
      setLocating(false);
    }
  }

  function runSearch(p = { name, type, focus, loc }) {
    const l = p.loc;
    if (!l) return;
    setActive("local");
    setSelectedCats([]);
    for (const t of TIERS) {
      setTiers((s) => ({ ...s, [t.id]: { status: "loading", grants: [] } }));
      searchFn({ data: { name: p.name, type: p.type, city: l.city, state: l.state, region: l.region, focus: p.focus, tier: t.id } })
        .then((grants) => setTiers((s) => ({ ...s, [t.id]: { status: "done", grants } })))
        .catch((err) =>
          setTiers((s) => ({ ...s, [t.id]: { status: "error", grants: [], error: err instanceof Error ? err.message : "Search failed" } })),
        );
    }
  }

  const ranFor = useRef<string | null>(null);
  useEffect(() => {
    if (!savedId || ranFor.current === savedId) return;
    const s = saved.searches.find((x) => x.id === savedId);
    if (!s) return;
    ranFor.current = savedId;
    setName(s.name);
    setType(s.type);
    setFocus(s.focus);
    setProfile(s.profile ?? { mission: "", goals: "" });
    setLoc(s.loc);
    setJustSaved(true);
    runSearch(s);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [savedId, saved.searches]);

  const searched = Object.values(tiers).some((t) => t.status !== "idle");
  const current = tiers[active];
  const doneGrants = current.status === "done" ? current.grants : [];
  const availableCats = CATEGORY_IDS.filter((c) => doneGrants.some((g) => catOf(g) === c));
  const visible = selectedCats.length === 0 ? doneGrants : doneGrants.filter((g) => selectedCats.includes(catOf(g)));

  return (
    <div className="min-h-screen paper-grain">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 pt-10">
        <p className="text-sm font-semibold tracking-[0.2em] text-primary uppercase">Grantscope</p>
        <Link to="/saved" className="rounded border border-primary px-4 py-2 text-sm font-medium text-primary transition hover:bg-secondary">
          ★ My grants{favorites.favs.length ? ` (${favorites.favs.length})` : ""}
        </Link>
      </header>

      <main className="mx-auto max-w-6xl px-6 pb-24">
        <section className="grid gap-10 pt-12 md:grid-cols-[1.1fr_1fr] md:items-end">
          <div>
            <h1 className="text-5xl leading-[1.05] font-semibold text-primary md:text-7xl">
              Funding, mapped from your <em className="text-accent">doorstep</em> outward.
            </h1>
            <p className="mt-6 max-w-md text-lg text-muted-foreground">
              Foundation grants for nonprofits, schools and municipalities — searched in three rings: local, state & regional, and national.
            </p>
          </div>

          <form onSubmit={findLocation} className="rounded border border-border bg-card p-6 shadow-sm">
            <label className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">Organization</label>
            <input
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Boulder Valley School District"
              className="mt-2 w-full rounded border border-input bg-background px-3 py-2.5 outline-none focus:ring-2 focus:ring-ring"
            />
            <div className="mt-4 grid grid-cols-3 gap-2">
              {(["nonprofit", "education", "municipality"] as const).map((t) => (
                <button
                  type="button"
                  key={t}
                  onClick={() => setType(t)}
                  className={`rounded border px-2 py-2 text-sm capitalize transition ${type === t ? "border-primary bg-primary text-primary-foreground" : "border-input bg-background hover:bg-secondary"}`}
                >
                  {t === "nonprofit" ? "Non-profit" : t}
                </button>
              ))}
            </div>
            <label className="mt-4 block text-xs font-semibold tracking-wider text-muted-foreground uppercase">Focus areas (optional)</label>
            <input
              value={focus}
              onChange={(e) => setFocus(e.target.value)}
              placeholder="e.g. STEM education, food security, parks"
              className="mt-2 w-full rounded border border-input bg-background px-3 py-2.5 outline-none focus:ring-2 focus:ring-ring"
            />
            <button
              disabled={locating}
              className="mt-5 w-full rounded bg-primary px-4 py-3 font-medium text-primary-foreground transition hover:opacity-90 disabled:opacity-60"
            >
              {locating ? "Locating…" : "Find location"}
            </button>
            {locError && <p className="mt-3 text-sm text-destructive">{locError}</p>}
          </form>
        </section>

        <section className="mt-10 border-y border-border py-6">
          <h2 className="mb-4 text-2xl text-primary">Client eligibility profile</h2>
          <ProfileFields profile={profile} onChange={setProfile} />
        </section>

        {loc && (
          <section className="mt-12 rounded border border-border bg-card p-6">
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <p className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
                  {loc.found ? "Location found — edit if needed" : "We weren't sure — please confirm"}
                </p>
                <h2 className="mt-1 text-2xl text-primary">{loc.name}</h2>
                {loc.note && <p className="mt-1 text-sm text-muted-foreground">{loc.note}</p>}
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={() => {
                    saved.save({ name, type, focus, loc, profile });
                    setJustSaved(true);
                  }}
                  className="rounded border border-primary px-4 py-3 text-sm font-medium text-primary transition hover:bg-secondary"
                >
                  {justSaved ? "Saved ✓" : "Save search"}
                </button>
                <button
                  onClick={() => runSearch()}
                  disabled={!loc.city || !loc.state}
                  className="rounded bg-accent px-6 py-3 font-semibold text-accent-foreground transition hover:opacity-90 disabled:opacity-50"
                >
                  Search grants →
                </button>
              </div>
            </div>
            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {(["city", "state", "region"] as const).map((k) => (
                <div key={k}>
                  <label className="text-xs capitalize text-muted-foreground">{k}</label>
                  <input
                    value={loc[k]}
                    onChange={(e) => setLoc({ ...loc, [k]: e.target.value })}
                    className="mt-1 w-full rounded border border-input bg-background px-3 py-2 outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
              ))}
            </div>
          </section>
        )}

        {searched && (
          <section className="mt-12">
            <div className="flex flex-wrap gap-2 border-b border-border">
              {TIERS.map((t) => {
                const s = tiers[t.id];
                return (
                  <button
                    key={t.id}
                    onClick={() => setActive(t.id)}
                    className={`-mb-px flex items-baseline gap-2 border-b-2 px-4 py-3 transition ${active === t.id ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
                  >
                    <span className="font-display text-sm">{t.ring}</span>
                    <span className="font-medium">{t.label}</span>
                    <span className="text-xs">{s.status === "loading" ? "…" : s.status === "done" ? `(${s.grants.length})` : ""}</span>
                  </button>
                );
              })}
            </div>

            {current.status === "done" && current.grants.length > 0 && (
              <div className="mt-6 flex flex-wrap items-center gap-2">
                <span className="mr-1 text-xs font-semibold tracking-wider text-muted-foreground uppercase">Category</span>
                {availableCats.map((c) => {
                  const on = selectedCats.includes(c);
                  const count = current.grants.filter((g) => catOf(g) === c).length;
                  return (
                    <button
                      key={c}
                      onClick={() => setSelectedCats(on ? selectedCats.filter((x) => x !== c) : [...selectedCats, c])}
                      className={`rounded-full border px-3 py-1.5 text-sm transition ${on ? "border-primary bg-primary text-primary-foreground" : "border-input bg-background text-muted-foreground hover:bg-secondary"}`}
                    >
                      {CATEGORY_LABEL[c]} <span className="text-xs opacity-70">{count}</span>
                    </button>
                  );
                })}
                {selectedCats.length > 0 && (
                  <button
                    onClick={() => setSelectedCats([])}
                    className="ml-1 text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground"
                  >
                    Clear
                  </button>
                )}
              </div>
            )}

            <div className="mt-6">
              {current.status === "loading" && (
                <div className="grid gap-4 md:grid-cols-2">
                    {Array.from({ length: 6 }).map((_, i) => (
                      <div key={i} className="h-56 animate-pulse rounded border border-border bg-muted" />
                    ))}
                </div>
              )}
              {current.status === "error" && (
                <p className="rounded border border-destructive/40 bg-card p-4 text-destructive">{current.error}</p>
              )}
              {current.status === "done" && current.grants.length === 0 && (
                <p className="text-muted-foreground">No grants found for this radius.</p>
              )}
              {current.status === "done" && current.grants.length > 0 && visible.length === 0 && (
                <p className="text-muted-foreground">
                  No {selectedCats.map((c) => CATEGORY_LABEL[c].toLowerCase()).join(" or ")} grants in this radius — try another category.
                </p>
              )}
              {visible.length > 0 && (
                <div className="grid gap-4 md:grid-cols-2">
                  {visible.map((g, i) => (
                    <GrantCard key={`${active}-${i}`} g={g} profile={profile} organization={loc?.name || name} tier={active} onAssessment={(fit) => {
                      setTiers(prev => ({ ...prev, [active]: { ...prev[active], grants: prev[active].grants.map(item => grantKey(item) === grantKey(g) ? { ...item, eligibility: fit } : item) } }));
                      if (favorites.isFav(g)) favorites.update(grantKey(g), { grant: { ...g, eligibility: fit } });
                    }} fav={favorites.isFav(g)} onFav={() => favorites.toggle(g, active, loc?.name || name)} />
                  ))}
                </div>
              )}
            </div>
            <p className="mt-8 text-xs text-muted-foreground">
              Results are AI-researched. Always confirm amounts, eligibility and deadlines on the foundation's website.
            </p>
          </section>
        )}
      </main>
    </div>
  );
}

function GrantCard({ g, fav, onFav, profile, organization, tier, onAssessment }: { g: Grant; fav: boolean; onFav: () => void; profile: ClientProfile; organization: string; tier: Tier; onAssessment: (fit: FitAssessment) => void }) {
  const color = { Low: "bg-low", Medium: "bg-medium", High: "bg-high" }[g.complexity];
  const href = /^https?:\/\//.test(g.website) ? g.website : `https://${g.website}`;
  const applyHref = g.applicationUrl
    ? /^https?:\/\//.test(g.applicationUrl)
      ? g.applicationUrl
      : `https://${g.applicationUrl}`
    : href;
  return (
    <article className="flex flex-col rounded border border-border bg-card p-6 transition hover:shadow-md">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">{g.foundation}</p>
        <div className="flex items-center gap-2">
          <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground">
            {CATEGORY_LABEL[catOf(g)]}
          </span>
          <button
            onClick={onFav}
            aria-label={fav ? "Remove from favorites" : "Save to favorites"}
            className={`text-xl leading-none transition ${fav ? "text-accent" : "text-muted-foreground hover:text-accent"}`}
          >
            {fav ? "★" : "☆"}
          </button>
        </div>
      </div>
      <h3 className="mt-1 text-xl text-primary">{g.program}</h3>
      <p className="mt-3 flex-1 text-sm leading-relaxed">{g.summary}</p>
      <dl className="mt-5 grid grid-cols-3 gap-3 border-t border-border pt-4 text-sm">
        <div>
          <dt className="text-xs text-muted-foreground">Funding</dt>
          <dd className="font-semibold">{range(g)}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground">Deadline</dt>
          <dd className="font-semibold">{g.deadline}</dd>
        </div>
        <div>
          <dt className="text-xs text-muted-foreground">Complexity</dt>
          <dd className="flex items-center gap-1.5 font-semibold" title={g.complexityNote}>
            <span className={`h-2 w-2 rounded-full ${color}`} />
            {g.complexity}
          </dd>
        </div>
      </dl>
      <p className="mt-2 text-xs text-muted-foreground">{g.complexityNote}</p>
      <GrantEligibility grant={g} profile={profile} organization={organization} tier={tier} onAssessment={onAssessment} />
      <div className="mt-4 flex flex-wrap items-center gap-4">
        <a
          href={applyHref}
          target="_blank"
          rel="noreferrer"
          className="rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
        >
          Apply ↗
        </a>
        {applyHref !== href && (
          <a href={href} target="_blank" rel="noreferrer" className="text-sm font-medium text-primary underline underline-offset-4 hover:text-accent">
            Foundation website
          </a>
        )}
      </div>
    </article>
  );
}
