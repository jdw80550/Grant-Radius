import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { STATUSES, useFavorites, useSavedSearches, type AppStatus } from "@/lib/saved";
import { GrantEligibility } from "@/components/grant-eligibility";

export const Route = createFileRoute("/saved")({
  head: () => ({
    meta: [
      { title: "My grants — Grantscope" },
      { name: "description", content: "Your favorite grants, application status tracking and saved searches." },
      { property: "og:title", content: "My grants — Grantscope" },
      { property: "og:description", content: "Track the foundation grants you're applying to." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SavedPage,
});

const TIER_LABEL = { local: "Local", regional: "State & Regional", national: "National" } as const;

function SavedPage() {
  const { favs, update, remove } = useFavorites();
  const { searches, remove: removeSearch } = useSavedSearches();
  const [filter, setFilter] = useState<AppStatus | "all">("all");
  const shown = filter === "all" ? favs : favs.filter((f) => f.status === filter);

  return (
    <div className="min-h-screen paper-grain">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 pt-10">
        <Link to="/" className="text-sm font-semibold tracking-[0.2em] text-primary uppercase">Grantscope</Link>
        <Link to="/" className="text-sm font-medium text-primary underline underline-offset-4">← Back to search</Link>
      </header>
      <main className="mx-auto max-w-6xl px-6 pb-24">
        <h1 className="pt-12 text-5xl font-semibold text-primary">My grants</h1>

        <section className="mt-10">
          <h2 className="text-2xl text-primary">Saved searches</h2>
          {searches.length === 0 ? (
            <p className="mt-3 text-muted-foreground">No saved searches yet. Use "Save search" after finding a location.</p>
          ) : (
            <ul className="mt-4 grid gap-3 sm:grid-cols-2">
              {searches.map((s) => (
                <li key={s.id} className="flex items-center justify-between gap-3 rounded border border-border bg-card p-4">
                  <div>
                    <p className="font-medium">{s.loc.name || s.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {s.loc.city}, {s.loc.state}{s.focus ? ` · ${s.focus}` : ""}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <Link to="/" search={{ s: s.id }} className="rounded bg-primary px-3 py-1.5 text-sm font-semibold text-primary-foreground">Run</Link>
                    <button onClick={() => removeSearch(s.id)} className="text-xs text-muted-foreground hover:text-destructive">Delete</button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="mt-12">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-2xl text-primary">Favorites & applications</h2>
            <div className="flex flex-wrap gap-2">
              {[{ id: "all" as const, label: "All" }, ...STATUSES].map((s) => {
                const count = s.id === "all" ? favs.length : favs.filter((f) => f.status === s.id).length;
                return (
                  <button
                    key={s.id}
                    onClick={() => setFilter(s.id)}
                    className={`rounded-full border px-3 py-1.5 text-sm transition ${filter === s.id ? "border-primary bg-primary text-primary-foreground" : "border-input bg-background text-muted-foreground hover:bg-secondary"}`}
                  >
                    {s.label} <span className="text-xs opacity-70">{count}</span>
                  </button>
                );
              })}
            </div>
          </div>
          {shown.length === 0 ? (
            <p className="mt-4 text-muted-foreground">Nothing here yet. Tap ☆ on any grant card to save it.</p>
          ) : (
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {shown.map((f) => {
                const g = f.grant;
                const site = /^https?:\/\//.test(g.website) ? g.website : `https://${g.website}`;
                const apply = g.applicationUrl ? (/^https?:\/\//.test(g.applicationUrl) ? g.applicationUrl : `https://${g.applicationUrl}`) : site;
                return (
                  <article key={f.key} className="flex flex-col rounded border border-border bg-card p-6">
                    <p className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
                      {g.foundation} · {TIER_LABEL[f.tier]}
                    </p>
                    <h3 className="mt-1 text-xl text-primary">{g.program}</h3>
                    <p className="mt-1 text-xs text-muted-foreground">For {f.org} · Deadline: {g.deadline}</p>
                    <p className="mt-3 text-sm leading-relaxed">{g.summary}</p>
                    <GrantEligibility grant={g} organization={f.org} tier={f.tier} status={STATUSES.find(s => s.id === f.status)?.label} notes={f.notes} onAssessment={fit => update(f.key, { grant: { ...g, eligibility: fit } })} />
                    <label className="mt-4 text-xs text-muted-foreground">Status</label>
                    <select
                      value={f.status}
                      onChange={(e) => update(f.key, { status: e.target.value as AppStatus })}
                      className="mt-1 rounded border border-input bg-background px-3 py-2"
                    >
                      {STATUSES.map((s) => (
                        <option key={s.id} value={s.id}>{s.label}</option>
                      ))}
                    </select>
                    <label className="mt-3 text-xs text-muted-foreground">Notes</label>
                    <textarea
                      value={f.notes}
                      onChange={(e) => update(f.key, { notes: e.target.value })}
                      rows={2}
                      placeholder="Contact, submission date, next steps…"
                      className="mt-1 rounded border border-input bg-background px-3 py-2 text-sm"
                    />
                    <div className="mt-4 flex items-center gap-4">
                      <a href={apply} target="_blank" rel="noreferrer" className="rounded bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Apply ↗</a>
                      <button onClick={() => remove(f.key)} className="ml-auto text-xs text-muted-foreground hover:text-destructive">Remove</button>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
